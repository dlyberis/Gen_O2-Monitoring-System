package main

// see /plugins/common/shim/example/cmd/main.go instead.
