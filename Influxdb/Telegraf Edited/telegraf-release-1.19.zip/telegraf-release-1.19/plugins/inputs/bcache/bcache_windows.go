// +build windows

package bcache
