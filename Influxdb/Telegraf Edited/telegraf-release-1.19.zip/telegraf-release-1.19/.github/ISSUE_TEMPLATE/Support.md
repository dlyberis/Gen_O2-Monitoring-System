---
name: Support request
labels: support
about: Open a support request

---

<!--
WOAHH, hold up. This isn't this best place for support questions. 
  You can get a faster response on slack or forums:

Please redirect any QUESTIONS about Telegraf usage to 
- InfluxData Slack Channel: https://www.influxdata.com/slack 
- InfluxData Community Site: https://community.influxdata.com

Check the documentation for the related plugin including the troubleshooting
section if available.

https://docs.influxdata.com/telegraf
https://github.com/influxdata/telegraf/tree/master/docs

-->
